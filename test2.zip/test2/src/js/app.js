(function() {
    
    // Question 0
    // Use npm to install jquery and holder.js
    // Add a reference to jquery and holder.js in your index.html in the appropriate spot
    
    // Complete all steps using jquery.
    // Changes to index.html should not be necessary unless specifically mentioned

    // Question 1
    // Update the page title to say "YOUR NAME - Test 2"
    // Update the navbar title to say "YOUR NAME"
    $('title').text('AMAN GULATI - Test 2');
    $('.navbar-brand').text('AMAN GULATI');

    // Replace the footer text with a copyright symbol and the year, using the Date object.
    const currentYear = new Date().getFullYear();
    $('footer .container').html('&copy; ' + currentYear);

    // Question 2
    // get a reference to the test table
    // get a reference to the second row in the table
    // update the student number to be 100100100
    $('#test-table tbody tr:eq(1) td:eq(2)').text('100100100');

    // Question 3
    // create a table row with your own information
    // create a table delimeter and set your first name
    // add it to your table row
    // create a table delimeter and set your last name
    // add it to your table row
    // create a table delimeter and set your banner id
    // add it to your table row
    // add your row to the test table body
    const newRow = $('<tr></tr>');
    const firstNameCell = $('<td></td>').text('AMAN');
    const lastNameCell = $('<td></td>').text('GULATI');
    const bannerIdCell = $('<td></td>').text('100886369');

    newRow.append(firstNameCell, lastNameCell, bannerIdCell);
    $('#test-table tbody').append(newRow);

    // Question 4
    // remove Alice Bobberts from the table
    $('#test-table tbody tr').eq(2).remove();

    // Question 5
    // add the .table-info class to your personal row
    newRow.addClass('table-info');

    // Question 6
    // remove the .table-warning class from Adam Kunz's row
    newRow.addClass('table-info');

    // Question 7
    // change .table-dark to .table-success for John Doe's row
    $('#test-table tbody tr:eq(1)').removeClass('table-dark').addClass('table-success');

    // Question 8
    // Go to https://getbootstrap.com/docs/5.3/components/card/
    // Using jquery, add a new container div to the <main> section
    // In that container, add a new bootstrap card. This should take several steps.
    // // make a card, make an image, append the image to the card
    // // make a card body, append it to the card
    // // make a heading, a paragraph, a link, append them to the card-body
    // // append the card to the new container
    // use holder.js to render the image in the card
    // add a heading with YOUR NAME in the card body, and a sentence or two about yourself.
    
    const cardContainer = $('<div class="container"></div>');
    const card = $('<div class="card"></div>');
    const cardImage = $('<img src="holder.js/100px180?text=Image&bg=373940" class="card-img-top" alt="Image">');
    const cardBody = $('<div class="card-body"></div>');
    const cardTitle = $('<h5 class="card-title">AMAN GULATI</h5>');
    const cardText = $('<p class="card-text">I study in Durham College.</p>');
    const cardLink = $('<a href="#" class="btn btn-primary">Learn more</a>');

    cardBody.append(cardTitle, cardText, cardLink);
    card.append(cardImage, cardBody);
    cardContainer.append(card);
    $('main').append(cardContainer);
})();